These are the python codes from my "Python OpenGL and PyOpenGL season 2" tutorial series on youtube. 
Link to the playlist: https://www.youtube.com/playlist?list=PL1P11yPQAo7rVh2N8butxleMYSiUngRnh